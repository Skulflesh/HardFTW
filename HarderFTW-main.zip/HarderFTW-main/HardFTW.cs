using Terraria.ModLoader;

namespace HardFTW
{
	public class HardFTW : Mod
	{
	}
}